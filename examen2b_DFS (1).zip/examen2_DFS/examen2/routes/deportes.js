const express = require('express')
//Mini aplicacion de express
const router = express.Router()
const deportesController = require('../controllers/deportes')

//Servicio para procesar los datos del formulario  CREATE
router.post('/agregarDeporte',deportesController.postAgregarDeporte)
//Consulta de Cartas  READ
router.get('/obtenerDeportes',deportesController.getObtenerDeporte)

module.exports = router