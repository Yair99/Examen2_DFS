const Sequelize = require("sequelize")

const Deportes = (sequelize)=>{
    sequelize.define('Deportes',{
        nombre:{
            type:Sequelize.STRING,
            allowNull: false,
            primaryKey: true
        },
        pais:{
            type:Sequelize.STRING,
            allowNull:false
        },
        balon:{
            type:Sequelize.STRING,
            allowNull:false
        },
        color:{
            type:Sequelize.STRING,
            allowNull:false
        }
    })
}

module.exports = Deportes