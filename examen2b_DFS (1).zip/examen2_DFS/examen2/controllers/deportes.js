const path = require('path')
const Carta = require('../utils/database').models.deportes

exports.getObtenerDeportes = (req, res)=>{
    Deportes.findAll()
    .then(deportes =>{
        console.log(deportes)
        res.json(deportes)
    })
    .catch((err)=>{
        console.log(err)
        res.json({
            estado: "error"
        })
    })
    
}

exports.postAgregarDeporte = (req,res)=>{
    console.log(req.body)
    Deportes.create(req.body)
        .then(resultado=>{
            console.log("Registro exitoso");
            res.send("Registro exitoso");
        })
        .catch(error=>{
            console.log(error); 
            res.send("Ocurrio un error");
        })    
}