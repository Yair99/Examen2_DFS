//Representa a la biblioteca sequelize
const Sequelize = require("sequelize")

//Objeto de Conexion
const sequelize= new Sequelize('examen_DFS','admin','12345678',{
    dialect: 'mysql',
    host: 'http://database-2.cl2ws20puqsm.us-east-1.rds.amazonaws.com/', //Direccion IP
    define:{
        //No coloques createdAt y updateAt
        timestamps:false,
        //Evitar plural
        freezeTableName: true
    }
})

//Cargar todos los modelos
const modelDefiners = [
    //importar cada modelo dentro de la carpeta models
    require('../models/deportes'),
    
]

//Adherir al objeto de conexion
for (const modelDefiner of modelDefiners){
    modelDefiner(sequelize)
}


//Para poder usar en archivo externos la conexion
module.exports = sequelize;